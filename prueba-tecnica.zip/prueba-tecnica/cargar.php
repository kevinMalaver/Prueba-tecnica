<?php
	$nombre = $_FILES['archivo']['name'];
	$guardado=$_FILES['archivo']['tmp_name'];

	if(!file_exists('archivos')){
		mkdir('archivos',0777,true);
		if(file_exists('archivos')){
			move_uploaded_file($guardado, 'archivos/'.$nombre);
		}
	}
	else{
		move_uploaded_file($guardado, 'archivos/'.$nombre);
	}
	$archivo = fopen("archivos/".$nombre,"r") or die("problemas al abrir el archivo");
	$lectura = '';
	while(!feof($archivo))
	{
		$linea=fgets($archivo);
		if(nl2br($linea)){
			if($linea[strrpos($linea, ',')+1] == ''){
				header("Location: index.php");
				die();
				unlink("archivos/".$nombre);
			}
			elseif ($linea[strrpos($linea, ',')+1] > 3) {
				header("Location: index.php");
				die();
				unlink("archivos/".$nombre);
			}
		}
		$lectura = $lectura.$linea;
	
	}
	fclose($archivo);
	unlink("archivos/".$nombre);


	require 'database.php';
	$contador = 0;
	$temporal = '';

	for($i = 0; $i < strlen($lectura); $i++){
		if($lectura[$i] == ','){

			if($contador == 0){
				$email = $temporal;
				$contador=$contador+1;
				
			}
			elseif($contador == 1){
				$nombre = $temporal;
				$contador=$contador+1;

			}
			elseif($contador == 2){
				$apellido = $temporal;
				$codigo = intval($lectura[$i+1]);

				if ($codigo == 1){
					$sql = "INSERT INTO usuarios_activos (email, nombre, apellido) VALUES ('$email', '$nombre', '$apellido')";
				}
				elseif ($codigo == 2) {
				 	$sql = "INSERT INTO usuarios_inactivos (email, nombre, apellido) VALUES ('$email', '$nombre', '$apellido')";
				}
				else{
				 	$sql = "INSERT INTO usuarios_en_espera (email, nombre, apellido) VALUES ('$email', '$nombre', '$apellido')";
				}
	    		$stmt = mysqli_query($conexion, $sql);
				$i=$i+1;
				$contador = 0;
				$email = '';
				$nombre= '';
				$apellido= '';
			}
			$temporal= ''; 
		}
		else{
			$temporal= $temporal.$lectura[$i];
			
		}

	}


?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="css/style.css">
</head>
<body>
	<table>
		<tr><td><a href="index.php">voler</td></tr>
		<thead>
		<tr><td><h1>Usuarios Activos<h1></td></tr>
		</thead>
		<tr>
			<td><table>
				
				<tr>
					<td><h3>Email</h3></td>
					<td><h3>Nombre</h3></td>
					<td><h3>Apellido</h3></td>
				</tr>
				<?php
					$sql="SELECT * from usuarios_activos";
					$result = mysqli_query($conexion, $sql);
					while($mostrar= mysqli_fetch_array($result)){
				?>
				<tr>
					<td><?php echo $mostrar['email']; ?></td>
					<td><?php echo $mostrar['nombre']; ?></td>
					<td><?php echo $mostrar['apellido']; ?></td>
				</tr>
				<?php
					}
				?>
			</table></td>
		</tr>
		<thead>
		<tr><td><h2>Usuarios Inactivos<h2></td></tr>
		</thead>
		<tr>

			<td><table>
				<tr>
					<td><h3>Email</h3></td>
					<td><h3>Nombre</h3></td>
					<td><h3>Apellido</h3></td>
				</tr>
				<?php
					$sql="SELECT * from usuarios_inactivos";
					$result = mysqli_query($conexion, $sql);
					while($mostrar= mysqli_fetch_array($result)){
				?>
				<tr>
					<td><?php echo $mostrar['email']; ?></td>
					<td><?php echo $mostrar['nombre']; ?></td>
					<td><?php echo $mostrar['apellido']; ?></td>
				</tr>
				<?php
					}
				?>

			</table></td>
		</tr>
		<thead>
		<tr><td><h1>Usuarios en Espera<h1></td></tr>
		</thead>
		<tr>
			<td><table>
				<tr>
					<td><h3>Email</h3></td>
					<td><h3>Nombre</h3></td>
					<td><h3>Apellido</h3></td>
				</tr>
				<?php
					$sql="SELECT * from usuarios_en_espera";
					$result = mysqli_query($conexion, $sql);
					while($mostrar= mysqli_fetch_array($result)){
				?>
				<tr>
					<td><?php echo $mostrar['email']; ?></td>
					<td><?php echo $mostrar['nombre']; ?></td>
					<td><?php echo $mostrar['apellido']; ?></td>
				</tr>
				<?php
					}
				?>

			</table></td>
		</tr>
	</table>
</body>
</html>