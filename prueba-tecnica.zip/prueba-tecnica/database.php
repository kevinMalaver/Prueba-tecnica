<?php

$server = 'localhost';
$username = 'root';
$password = '';
$database = 'prueba_tecnica';

$conexion = mysqli_connect($server, $username,$password, $database);

?>