
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="css/style.css">
</head>
<body>
	
	<form action="cargar.php" method="post" enctype="multipart/form-data">
		<div id = "principal">
			<table>
				<thead>
				<tr><td><h2>Formulario de carga de informacion</h2></td></tr>
				</thead>
				<tr><td><input type="file" name="archivo"></td></tr>
				<tr><td><input type="submit" value="Enviar Formulario"></td></tr>
			</table>
		</div>
	</form> 
		
	</table>
</body>
</html>