
CREATE DATABASE prueba_tecnica;
USE prueba_tecnica;
CREATE TABLE 'prueba_tecnica'.'usuarios_activos' ( 'id' INT NOT NULL AUTO_INCREMENT , 'email' VARCHAR(200) NOT NULL , 'nombre' VARCHAR(50) NOT NULL , 'apellido' VARCHAR(50) NOT NULL , PRIMARY KEY ('id')) ENGINE = InnoDB;
CREATE TABLE 'prueba_tecnica'.'usuarios_inactivos' ( 'id' INT NOT NULL AUTO_INCREMENT , 'email' VARCHAR(200) NOT NULL , 'nombre' VARCHAR(50) NOT NULL , 'apellido' VARCHAR(50) NOT NULL , PRIMARY KEY ('id')) ENGINE = InnoDB;
CREATE TABLE `prueba_tecnica'.'usuarios_en_espera' ( 'id' INT NOT NULL AUTO_INCREMENT , 'email' VARCHAR(200) NOT NULL , 'nombre' VARCHAR(50) NOT NULL , 'apellido' VARCHAR(50) NOT NULL , PRIMARY KEY ('id')) ENGINE = InnoDB;